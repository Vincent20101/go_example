package calc

//蛇形
/*
	返回：int类型 返回相加的结果
	参数:x 加数， y 被加数
*/
//
//sphinx
func Add(x, y int) int {
	return x + y //x+y结果
}
