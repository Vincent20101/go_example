package ch11

func add(a, b int) int {
	return a+b
}
