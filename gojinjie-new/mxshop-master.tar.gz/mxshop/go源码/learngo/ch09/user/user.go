package user

import "fmt"

func init(){
	fmt.Println("this is c09 user init")
}
