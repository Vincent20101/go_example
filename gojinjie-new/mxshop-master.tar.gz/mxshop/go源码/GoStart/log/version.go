package log

// Version is the current release version.
func Version() string {
	return "0.1.14"
}
