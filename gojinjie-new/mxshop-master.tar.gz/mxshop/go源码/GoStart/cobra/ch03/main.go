/*
Copyright © 2022 NAME HERE <EMAIL ADDRESS>

*/
package main

import "GoStart/cobra/ch03/cmd"

func main() {
	cmd.Execute()
}
