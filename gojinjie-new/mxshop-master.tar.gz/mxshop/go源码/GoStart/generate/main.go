package main

import (
	"GoStart/generate/code"
	"fmt"
)

// 课后作业 copier的实现原理，自己给个评估， 会不会影响性能， 写benchmark去测试三种方法 1. 自己手动映射 2. 匿名嵌入 3. copier
func main() {
	fmt.Println(code.ERR_CODE_INVALID_PARAMS)
}
