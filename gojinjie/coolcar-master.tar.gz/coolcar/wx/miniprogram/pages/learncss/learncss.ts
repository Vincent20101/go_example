Page({
  data: {
    showPath: true,
    values: [
      {
        name: 'john',
        id: 1,
      },
      {
        name: 'mary',
        id: 2,
      },
      {
        name: 'tom',
        id:3,
      },
    ],
  },
})
