export type ModalResult = 'ok'|'cancel'|'close'
