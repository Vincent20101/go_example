'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // BASE_API: '"http://120.27.63.9:8080"',
  BASE_API : '"http://192.168.0.103:8000/"'

}
